﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine;

public class ButtonPress : MonoBehaviour {
    public bool pressed;
	// Use this for initialization
	void Start () {
        pressed = false;
	}
	
	// Update is called once per frame
	void Update () {
        GameObject.Find("Canvas").GetComponent<CanvasScaler>().scaleFactor = Screen.width / 1024;
        /*
       GameObject.Find("Start").GetComponent<RectTransform>().localScale = new Vector3(2 * (Screen.width / 1024), 2 * (Screen.height / 768), 2);
        GameObject.Find("Start").GetComponent<RectTransform>().position = new Vector3(gameObject.GetComponent<RectTransform>().position.x * (1 + (2 / gameObject.GetComponent<RectTransform>().localScale.x)), gameObject.GetComponent<RectTransform>().position.y * (1 + (2 / gameObject.GetComponent<RectTransform>().localScale.y)), gameObject.GetComponent<RectTransform>().position.z * (1 + (2 / gameObject.GetComponent<RectTransform>().localScale.z)));
	
    */}
	public void BackOptions(){
		SceneManager.LoadScene ("TitleScreen");
	
	}
    public void StartButton() {
        if (GameObject.Find("StartText").GetComponent<Text>().text != "New Game")
        {
            GameObject.Find("StartText").GetComponent<Text>().text = "New Game";
            GameObject.Find("OptionsText").GetComponent<Text>().text = "Continue";
            GameObject.Find("QuitText").GetComponent<Text>().text = "<- Back";
        }else
        {
            SceneManager.LoadScene("Start");
        }


    }
    public void OptionButton()
    {
        if (GameObject.Find("OptionsText").GetComponent<Text>().text != "Continue")
        {
            SceneManager.LoadScene("Options");
            Debug.Log("4");
        }else
        {
            Debug.Log("3");
            
        }
        
    }
    public void QuitButton() {
        if (GameObject.Find("QuitText").GetComponent<Text>().text != "<- Back")
        {
            //If we are running in a standalone build of the game
#if UNITY_STANDALONE
            //Quit the application
            Application.Quit();
#endif

            //If we are running in the editor
#if UNITY_EDITOR
            //Stop playing the scene
            UnityEditor.EditorApplication.isPlaying = false;
#endif
        }
        else
        {
            GameObject.Find("StartText").GetComponent<Text>().text = "START";
            GameObject.Find("OptionsText").GetComponent<Text>().text = "OPTIONS";
            GameObject.Find("QuitText").GetComponent<Text>().text = "QUIT";
        }
    }
}
