﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainMenuGUI : MonoBehaviour {
    public int widthOfButton;
    public int heightOfButton;
    public Texture2D buttonBackground;
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
    void OnGUI() {
        GUIStyle style = new GUIStyle();
        style.fontSize = 28;
        style.normal.textColor = Color.blue;
        style.wordWrap = true;
        GUI.Label(new Rect((Screen.width / 2) - (widthOfButton / 4), (Screen.height / 2) - (heightOfButton / 4), buttonBackground.width*100,buttonBackground.height*100), buttonBackground);
        GUI.Label(new Rect((Screen.width / 2)-(widthOfButton/4), (Screen.height / 2)-(heightOfButton/4), widthOfButton, heightOfButton), "Start",style);
    }
}
