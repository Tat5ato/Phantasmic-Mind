﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine;

public class ButtonPress : MonoBehaviour {
    public bool pressed;
	// Use this for initialization
	void Start () {
        pressed = false;
	}
	
	// Update is called once per frame
	void Update () {
		
	}
    public void StartButton() {
        if (GameObject.Find("StartText").GetComponent<Text>().text != "New Game")
        {
            GameObject.Find("StartText").GetComponent<Text>().text = "New Game";
            GameObject.Find("OptionsText").GetComponent<Text>().text = "Continue";
            GameObject.Find("QuitText").GetComponent<Text>().text = "<- Back";
        }else
        {
            SceneManager.LoadScene("Start");
        }


    }
    public void OptionButton()
    {
        if (GameObject.Find("OptionsText").GetComponent<Text>().text != "Continue")
        {
            SceneManager.LoadScene("Options");
            Debug.Log("4");
        }else
        {
            Debug.Log("3");
            
        }
        
    }
    public void QuitButton() {
        if (GameObject.Find("QuitText").GetComponent<Text>().text != "<- Back")
        {
            //If we are running in a standalone build of the game
#if UNITY_STANDALONE
            //Quit the application
            Application.Quit();
#endif

            //If we are running in the editor
#if UNITY_EDITOR
            //Stop playing the scene
            UnityEditor.EditorApplication.isPlaying = false;
#endif
        }
        else
        {
            GameObject.Find("StartText").GetComponent<Text>().text = "Start";
            GameObject.Find("OptionsText").GetComponent<Text>().text = "Options";
            GameObject.Find("QuitText").GetComponent<Text>().text = "Quit";
        }
    }
}
